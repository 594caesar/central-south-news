package com.tiedao.async;

import java.util.List;

/**
 * Created by cbj on 2017/8/11.
 */
public interface EventHandler {
    void doHandle(EventModel model);
    List<EventType> getSupportEventTypes();
}
