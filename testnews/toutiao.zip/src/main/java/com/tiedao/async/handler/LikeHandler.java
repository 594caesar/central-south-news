package com.tiedao.async.handler;

import com.tiedao.async.EventHandler;
import com.tiedao.async.EventModel;
import com.tiedao.async.EventType;
import com.tiedao.model.Message;
import com.tiedao.model.User;
import com.tiedao.service.MessageService;
import com.tiedao.service.UserService;
import com.tiedao.util.MailSender;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * Created by cbj on 2017/8/11.
 */
@Component
public class LikeHandler implements EventHandler {
    @Autowired
    MessageService messageService;

    @Autowired
    UserService userService;

    @Autowired
    MailSender mailSender;

    @Override
    public void doHandle(EventModel model) {
        Message message = new Message();
        User user = userService.getUser(model.getActorId());
        message.setToId(model.getActorId());
        message.setContent("用户" + user.getName() +
                " 赞了你的资讯,http://127.0.0.1:8080/news/"
                + String.valueOf(model.getEntityId()));
        // SYSTEM ACCOUNT
        message.setFromId(3);
        message.setCreatedDate(new Date());
        message.setConversationId(model.getActorId()<model.getEntityOwnerId()
                ?String.format("%d_%d",model.getActorId(),model.getEntityOwnerId())
                :String.format("%d_%d",model.getEntityOwnerId(),model.getActorId()));
        messageService.addMessage(message);

        Map<String, Object> map = new HashMap();
        map.put("username",user.getName());
        mailSender.sendWithHTMLTemplate("879104913@qq.com", "给你点赞啦",
                "mails/welcome.html", map);
    }

    @Override
    public List<EventType> getSupportEventTypes() {
        return Arrays.asList(EventType.LIKE);
    }
}
