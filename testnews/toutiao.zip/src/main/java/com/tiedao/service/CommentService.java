package com.tiedao.service;

import com.tiedao.controller.NewsController;
import com.tiedao.dao.CommentDao;
import com.tiedao.model.Comment;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by cbj on 2017/8/11.
 */
@Service
public class CommentService {
    private static  final org.slf4j.Logger logger = LoggerFactory.getLogger(NewsController.class);

    @Autowired
    private CommentDao commentDao;

    public List<Comment> getCommentsByEntity(int entityId,int entityType){
        return commentDao.selectByEntity(entityId,entityType);
    }

    public int addComment(Comment comment){
        return commentDao.addComment(comment);
    }

    public int getCommentCount(int entityId,int entityType){
        return commentDao.getCommentCount(entityId,entityType);
    }

    //删除评论
    /*public void deleteComment(int entityId,int entityType){
        commentDao.updateStatus(entityId,entityType,1);
    }*/
}
