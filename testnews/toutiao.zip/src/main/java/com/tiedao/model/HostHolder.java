package com.tiedao.model;

import org.springframework.stereotype.Component;

/**
 * Created by cbj on 2017/8/8.
 */
@Component
public class HostHolder {//存通过ticket找出来的User
    private static ThreadLocal<User> users = new ThreadLocal<>();

    public User getUser(){
        return users.get();
    }

    public void setUser(User user){
        users.set(user);
    }

    public void clear(){
        users.remove();
    }
}
