package com.tiedao.model;

/**
 * Created by cbj on 2017/8/11.
 */
public class EntityType {
    public static int ENTITY_NEWS = 1;
    public static int ENTITY_COMMET = 2;
}
